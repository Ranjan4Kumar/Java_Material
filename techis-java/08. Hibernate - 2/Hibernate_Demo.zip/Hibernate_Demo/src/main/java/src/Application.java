package src;

import org.hibernate.Session;
import org.hibernate.Transaction;
import entity.Student;
import util.HibernateUtil;
import java.util.List;


public class Application {


    public static void main(String[] args) {

        Student student = new Student("Pritam", "Sonawane", "pritamsonawane@gmail.com");
        Student student1 = new Student("Akshay", "Patil", "akshaypatil@gmail.com");
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // start a transaction
            transaction = session.beginTransaction();
            // save the student objects
            session.save(student);
            session.save(student1);
            // commit transaction
            transaction.commit();
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }

        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            List< Student > students = session.createQuery("from Student", Student.class).list();
            students.forEach(s -> {
                System.out.print("Student Name: "+ s.getFirstName());
                System.out.println("    "+s.getLastName());
            });
        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }
            e.printStackTrace();
        }
    }
}
