package com.example.demo.controller;

import com.example.demo.entity.Student;
import com.example.demo.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("student")
public class DemoController {

    @Autowired
    private StudentService service;

    @PostMapping("/add")
    public void addStudent(@RequestBody Student student) {
        service.addStudent(student);
    }

    @DeleteMapping("/remove/{id}")
    public void removeStudent(@PathVariable Integer id){
        service.removeStudent(id);
    }

    @GetMapping("/getall")
    public List<Student> getAllStudents(){
        return service.getAllStudents();
    }

    @GetMapping("/get/{id}")
    public Student getStudent(@PathVariable Integer id){
        return service.getStudent(id);
    }

    @PutMapping("/update/{id}")
    public void updateStudent(@RequestBody Student newStudent, @PathVariable Integer id){
        service.updateStudent(newStudent, id);
    }


}
